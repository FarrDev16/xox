let board = [];
let currentPlayer = 'X';
let gameActive = false;
let boardSize = 3;
let moveHistory = [];
let mode = 'cpu';
let player1 = 'Pemain 1';
let player2 = 'Komputer';

function startGame() {
  boardSize = 3;
  board = Array(boardSize * boardSize).fill('');
  currentPlayer = 'X';
  gameActive = true;
  moveHistory = [];
  mode = document.getElementById('mode').value;
  player1 = document.getElementById('player1').value || 'Pemain 1';
  player2 = mode === 'cpu' ? 'Komputer' : (document.getElementById('player2').value || 'Pemain 2');
  document.getElementById('message').classList.add('hidden');
  drawBoard();
  updateTurnText();
  if (mode === 'cpu' && currentPlayer === 'O') aiMove();
}

function drawBoard() {
  const boardEl = document.getElementById('board');
  boardEl.innerHTML = '';
  boardEl.style.gridTemplateColumns = `repeat(${boardSize}, var(--cell-size))`;
  board.forEach((cell, i) => {
    const div = document.createElement('div');
    div.className = 'cell';
    div.innerText = cell;
    div.onclick = () => handleMove(i);
    boardEl.appendChild(div);
  });
}

function handleMove(i) {
  if (!gameActive || board[i]) return;
  board[i] = currentPlayer;
  moveHistory.push(i);
  playSound('clickSound');
  checkWinOrDraw();
  switchPlayer();
  updateTurnText();
  drawBoard();
  if (mode === 'cpu' && currentPlayer === 'O') setTimeout(aiMove, 300);
}

function switchPlayer() {
  currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
}

function checkWinOrDraw() {
  const lines = [];
  for (let i = 0; i < boardSize; i++) {
    lines.push([...Array(boardSize)].map((_, j) => i * boardSize + j));
    lines.push([...Array(boardSize)].map((_, j) => j * boardSize + i));
  }
  lines.push([...Array(boardSize)].map((_, i) => i * (boardSize + 1)));
  lines.push([...Array(boardSize)].map((_, i) => (i + 1) * (boardSize - 1)));

  for (const line of lines) {
    const [a, ...rest] = line;
    if (board[a] && rest.every(i => board[i] === board[a])) {
      gameActive = false;
      showMessage(`${board[a]} Menang!`);
      playSound('winSound');
      return;
    }
  }

  if (board.every(cell => cell)) {
    gameActive = false;
    showMessage('Seri!');
    playSound('drawSound');
  }
}

function undo() {
  if (!moveHistory.length) return;
  const last = moveHistory.pop();
  board[last] = '';
  drawBoard();
  switchPlayer();
  updateTurnText();
}

function resetGame() {
  startGame();
}

function showMessage(msg) {
  document.getElementById('messageText').innerText = msg;
  document.getElementById('message').classList.remove('hidden');
}

function updateTurnText() {
  document.getElementById('turn').innerText = `Giliran: ${currentPlayer === 'X' ? player1 : player2}`;
}

function toggleTheme() {
  const body = document.body;
  body.classList.toggle('theme1');
  body.classList.toggle('theme2');
}

function aiMove() {
  let i = board.findIndex(cell => !cell);
  handleMove(i);
}

function playSound(id) {
  const audio = document.getElementById(id);
  if (audio) audio.play();
}